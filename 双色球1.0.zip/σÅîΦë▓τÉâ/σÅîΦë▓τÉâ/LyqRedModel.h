//
//  LyqRedModel.h
//  双色球
//
//  Created by pro on 2018/2/7.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LyqRedModel : NSObject

@property (nonatomic ,strong) NSMutableArray *rednumArrays;
@property (nonatomic ,copy) NSString *blueText;

+(LyqRedModel *)model;

@end
