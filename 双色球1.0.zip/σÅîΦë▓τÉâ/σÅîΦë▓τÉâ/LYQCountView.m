//
//  LYQCountView.m
//  双色球
//
//  Created by pro on 2018/2/7.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQCountView.h"

@implementation LYQCountView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.bollLabel.layer.cornerRadius = 15;
    self.bollLabel.layer.masksToBounds = YES;
    

    
}
@end
