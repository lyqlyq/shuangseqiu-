//
//  LYQSSQResultController.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQSSQResultController : UIViewController

@property (nonatomic ,strong) NSMutableArray *sexModels;

@property (nonatomic ,copy) NSString *weiChastr;


@end
