//
//  LYQSSQResultController.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSSQResultController.h"
#import "LYQRedCell.h"
#import <WXApi.h>

#import "LYQRandomNumberTool.h"
#import "LYQRedOneNumberModel.h"
#import "LYQRedSexNumberModel.h"

@interface LYQSSQResultController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *timeLbale;
@property (weak, nonatomic) IBOutlet UILabel *weiChaLabel;

@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@property (weak, nonatomic) IBOutlet UITextField *countLable;

@end

@implementation LYQSSQResultController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选号结果";
    
    self.timeLbale.text = [self getDateStr];
    
    self.weiChaLabel.text = self.weiChastr;
    
   // self.infoLabel.text = @"没有 6 红产生";

//    [self.sexModels enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *sexRedModel, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (sexRedModel.is_sex_red) {
//            NSInteger index =  [self.sexModels indexOfObject:sexRedModel];
//            
//            self.infoLabel.text = [NSString stringWithFormat:@"当前第 -%ld- 注产生了 6 红",index + 1];
//            
//        }
//    }];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"微信分享" style:0 target:self action:@selector(wechatFenXiang)];
    
    self.navigationItem.rightBarButtonItem = item;
    
    
    
}
/**50注*/
-(NSString *)get50TextCount{
   
    NSInteger count = [self.countLable.text integerValue];
    
  __block  NSString *contentText = [NSString new];
    
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"%@\n",self.weiChastr]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"总注数%ld\n",count]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"%@\n",[self getDateStr]]];
    
    NSMutableArray *redModels = [LYQRandomNumberTool getRexModesWithArrays:self.sexModels count:count];
    [redModels enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        
    __block   NSString *sevenText = [NSString new];
        
        [model.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneModel, NSUInteger idx, BOOL * _Nonnull stop) {
        
            
            if (idx == model.redOneNumberModelArrays.count - 1) {
                  sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@"%02ld",oneModel.redNumber]];
            }else{
                    sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@"%02ld-",oneModel.redNumber]];
            }
        }];
    
        sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@" 蓝-%@",model.blueText]];
        
        contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"\n %@",sevenText]];
        
    }];
    
    
    
    
    return contentText;
}

-(void)wechatFenXiang{
    
    SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
    req.bText = YES;
    req.scene = WXSceneSession;
    req.text = [self get50TextCount];
    
    [WXApi sendReq:req];
    
}

-(NSString *)getDateStr{
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"当前日期:yyyy-MM-dd hh:mm:ss"];
    return [format1 stringFromDate:date];
}



#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.sexModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQRedCell *cell = [LYQRedCell redCellWithTableView:tableView];
    cell.sexModel = self.sexModels[indexPath.row];
    cell.countLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70.0f;
}




@end
