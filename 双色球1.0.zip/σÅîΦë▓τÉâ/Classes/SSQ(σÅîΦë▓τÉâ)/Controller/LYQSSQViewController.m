//
//  TuiJieViewController.m
//  双色球
//
//  Created by pro on 2018/2/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSSQViewController.h"

#import "LYQSSQResultController.h"
#import "LYQPotentialModel.h"
#import "LYQKillNumberModel.h"
#import "LYQRedSexNumberModel.h"
#import "LYQRedOneNumberModel.h"
#import "LYQConditionModel.h"


@interface LYQSSQViewController ()
/**时间*/
@property (weak, nonatomic) IBOutlet UILabel *timeLable;
/**龙头*/
@property (weak, nonatomic) IBOutlet UITextField *startTextF;
/**凤尾*/
@property (weak, nonatomic) IBOutlet UITextField *endTextF;
/**注数*/
@property (weak, nonatomic) IBOutlet UITextField *countTextF;
/**随机位差Button*/
@property (weak, nonatomic) IBOutlet UIButton *sjwcButton;

#pragma mark -----------------位差---------------------
@property (weak, nonatomic) IBOutlet UITextField *potentialOneTextF;
@property (weak, nonatomic) IBOutlet UITextField *potentialTwoTextF;
@property (weak, nonatomic) IBOutlet UITextField *potentialThereTextF;
@property (weak, nonatomic) IBOutlet UITextField *potentialFourTextF;
@property (weak, nonatomic) IBOutlet UITextField *potentialFiveTextF;

#pragma mark -----------------开奖号码---------------------
@property (weak, nonatomic) IBOutlet UITextField *WinningNumOne;
@property (weak, nonatomic) IBOutlet UITextField *WinningNumTwo;
@property (weak, nonatomic) IBOutlet UITextField *WinningNumThere;
@property (weak, nonatomic) IBOutlet UITextField *WinningNumFour;
@property (weak, nonatomic) IBOutlet UITextField *WinningNumFive;
@property (weak, nonatomic) IBOutlet UITextField *WinningNumSex;

#pragma mark -----------------杀号---------------------
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberOneTextF;
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberTwoTextF;
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberThereTextF;
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberFourTextF;
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberFiveTextF;
//@property (weak, nonatomic) IBOutlet UITextField *KillNumberSexTextF;
@property (weak, nonatomic) IBOutlet UITextField *redCount;

@property (nonatomic ,strong) LYQRedSexNumberModel *rightModel;

/**位差模型*/
@property (nonatomic ,strong) LYQPotentialModel *potentialModel;
/**杀号模型*/
@property (nonatomic ,strong) LYQKillNumberModel *killModel;
/**龙头 凤尾 位差 模型*/
@property (nonatomic ,strong) LYQConditionModel *conditionModel;
@property (weak, nonatomic) IBOutlet UIButton *gu1;
@property (weak, nonatomic) IBOutlet UIButton *gu2;
@property (weak, nonatomic) IBOutlet UIButton *gu3;
@property (weak, nonatomic) IBOutlet UITextField *lan1;
@property (weak, nonatomic) IBOutlet UITextField *lan2;
@property (weak, nonatomic) IBOutlet UITextField *lan3;
@property (weak, nonatomic) IBOutlet UITextField *lan4;
@property (weak, nonatomic) IBOutlet UITextField *lan5;
@property (weak, nonatomic) IBOutlet UITextField *lan6;


@property (nonatomic ,strong) NSMutableArray *lanArrays;

@end

@implementation LYQSSQViewController


-(LYQRedSexNumberModel *)rightModel{
    if (_rightModel == nil) {
        _rightModel = [[LYQRedSexNumberModel alloc] init];
    }
    return _rightModel;
}

-(LYQPotentialModel *)potentialModel{
    
    if (_potentialModel == nil) {
        _potentialModel = [[LYQPotentialModel alloc] init];
    }
    return _potentialModel;
    
}

-(LYQKillNumberModel *)killModel{
    if (_killModel == nil) {
        _killModel = [[LYQKillNumberModel alloc] init];
    }
    return _killModel;
}

-(LYQConditionModel *)conditionModel{
    if (_conditionModel == nil) {
        _conditionModel = [[LYQConditionModel alloc] init];
    }
    return _conditionModel;
}

-(NSMutableArray *)lanArrays
{
    if (_lanArrays == nil) {
        _lanArrays = [NSMutableArray array];
    }
    return _lanArrays;
    
}

-(void)viewDidLoad{
    [self setUpUI];
    

    
    
}
- (IBAction)gu1:(UIButton *)sender {
    sender.selected = !sender.selected;
}
- (IBAction)gu2:(UIButton *)sender {
    sender.selected = !sender.selected;

}
- (IBAction)gu3:(UIButton *)sender {
    sender.selected = !sender.selected;

}

/**给位差模型赋值*/
-(void)setPotentialModelNumber{
  
   
    self.potentialModel.poentialOne = [self.potentialOneTextF.text integerValue];
    self.potentialModel.poentialTwo = [self.potentialTwoTextF.text integerValue];
    self.potentialModel.poentialThere = [self.potentialThereTextF.text integerValue];
    self.potentialModel.poentialFour = [self.potentialFourTextF.text integerValue];
    self.potentialModel.poentialFive = [self.potentialFiveTextF.text integerValue];
    

    
}
/**获取随机位差模型*/
-(void)getRandomPotentialModel{
    LYQPotentialModel *random = [LYQPotentialModel potentialModelWithRandomNumber];
    
    if (self.gu1.selected) {
        
    }else{
        self.potentialOneTextF.text  = random.oneText;

    }
    if (self.gu2.selected) {
        
    }else{
        self.potentialTwoTextF.text = random.twoText;

    }
    
    if (self.gu3.selected ) {
        
    }else{
        self.potentialThereTextF.text = random.thereText;

    }
    
    
    self.potentialFourTextF.text = random.fourText;
    self.potentialFiveTextF.text = random.fiveText;

}
/**随机位差点击*/
- (IBAction)siwcButtonClick {
    [self getRandomPotentialModel];
    
}
/**给杀号模型赋值*/
-(void)setKillModelNumber{
    
//    return;
//    self.killModel.killNumOne = self.KillNumberOneTextF.text.integerValue;
//    self.killModel.killNumTwo = self.KillNumberTwoTextF.text.integerValue;
//    self.killModel.killNumThere = self.KillNumberThereTextF.text.integerValue;
//    self.killModel.killNumFour = self.KillNumberFourTextF.text.integerValue;
//    self.killModel.killNumFive = self.KillNumberFiveTextF.text.integerValue;
//    self.killModel.killNumSex = [self.KillNumberSexTextF.text integerValue];
    
}
/**给条件模型赋值*/
-(void)setConditionModel{
    
    self.conditionModel.pterisNumber = self.endTextF.text.integerValue;
    self.conditionModel.faucetNumber = self.startTextF.text.integerValue;
    self.conditionModel.numberTotial = self.countTextF.text.integerValue;
    self.conditionModel.remainedRedNumber = [self.redCount.text integerValue];

}


-(void)setwinningNumberSex{
    
    
    NSMutableArray *textFArrays = [NSMutableArray array];
    
    [textFArrays addObject:self.WinningNumOne];
    [textFArrays addObject:self.WinningNumTwo];
    [textFArrays addObject:self.WinningNumThere];
    [textFArrays addObject:self.WinningNumFive];
    [textFArrays addObject:self.WinningNumFour];
    [textFArrays addObject:self.WinningNumSex];
  
    NSMutableArray *rightNumberArray = [NSMutableArray array];
    
    for (NSInteger i = 0 ; i < textFArrays.count ; i ++) {
        
        LYQRedOneNumberModel *one = [[LYQRedOneNumberModel alloc] init];
        UITextField *textF = textFArrays[i];
        one.redNumber = [textF.text integerValue];
        [rightNumberArray addObject:one];
    }
    self.rightModel.redOneNumberModelArrays = rightNumberArray;
    
    
}

-(void)setSexBlueBool{
    NSMutableArray *textFArrays = [NSMutableArray array];
    
    [textFArrays addObject:self.lan1];
    [textFArrays addObject:self.lan2];
    [textFArrays addObject:self.lan3];
    [textFArrays addObject:self.lan4];
    [textFArrays addObject:self.lan5];
    [textFArrays addObject:self.lan6];
    
    for (NSInteger i = 0 ; i < textFArrays.count ; i ++) {
        
        UITextField *text = textFArrays[i];
        if (text.text.length > 0 && text.text.integerValue > 0) {
            if (text != nil) {
                 [self.lanArrays addObject:text.text];
            }
           
        }
     
    }
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


-(void)setUpUI{
    self.sjwcButton.layer.cornerRadius = 5;
    self.sjwcButton.layer.masksToBounds = YES;
    self.timeLable.text = [self getDateStr];
    
}

-(NSString *)getDateStr{
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"当前日期:yyyy-MM-dd"];
    return [format1 stringFromDate:date];
}



/**开始测号*/
- (IBAction)startClick:(UIButton *)sender {
    
    [self.view endEditing:YES];
    
    [self setPotentialModelNumber];
    [self setwinningNumberSex];
    [self setConditionModel];
    [self setSexBlueBool];
    
    NSMutableArray *sexModels  = [LYQRedSexNumberModel getRedSexNumberModesArrayWithPotentialModel:self.potentialModel conditionModel:self.conditionModel WithRightSexModel:self.rightModel lanArrays:self.lanArrays];
    
    
    LYQSSQResultController  *ssqResultVC =[[LYQSSQResultController alloc] init];
    ssqResultVC.sexModels = sexModels;
    
    ssqResultVC.weiChastr = [NSString stringWithFormat:@"位差为:%@-%@-%@-%@-%@",self.potentialOneTextF.text,self.potentialTwoTextF.text,self.potentialThereTextF.text,self.potentialFourTextF.text,self.potentialFiveTextF.text];
    
    [self.navigationController pushViewController:ssqResultVC animated:YES];
}


@end
