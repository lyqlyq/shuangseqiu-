//
//  LYQRedCell.m
//  双色球
//
//  Created by pro on 2018/3/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRedCell.h"
#import "LYQRedOneNumberModel.h"

#import "LYQRequestTool.h"
#import "LYQSSQParam.h"
#import "MJExtension.h"

#import "LYQAwardModel.h"

@interface LYQRedCell ()

@property (weak, nonatomic) IBOutlet UIView *redView;

@property (weak, nonatomic) IBOutlet UIScrollView *srcV;

@property (nonatomic ,assign) CGRect  lastFrame;
@property (weak, nonatomic) IBOutlet UILabel *yiDengCount;
@property (weak, nonatomic) IBOutlet UILabel *erDengCount;

@property (weak, nonatomic) IBOutlet UILabel *yiDengNumber;
@property (weak, nonatomic) IBOutlet UILabel *erDengNumber;
@property (weak, nonatomic) IBOutlet UILabel *yiDengTime;
@property (weak, nonatomic) IBOutlet UILabel *erDengTime;

@end
@implementation LYQRedCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.srcV.showsVerticalScrollIndicator = NO;
    self.srcV.showsHorizontalScrollIndicator = NO;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
}

+(instancetype)redCellWithTableView:(UITableView *)tableView{
    
    LYQRedCell *cell =  [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:nil options:nil] firstObject];
    return cell;
    
}

-(void)setSexModel:(LYQRedSexNumberModel *)sexModel{
    _sexModel = sexModel;
    
  
    NSMutableArray *numArray = [NSMutableArray array];
    
    
    [sexModel.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneModel, NSUInteger idx, BOOL * _Nonnull stop) {
        [numArray addObject:[NSString stringWithFormat:@"%02ld",oneModel.redNumber]];
    }];
    // 01 09 13 20 22 24 25 28 31 32 33:02
    LYQSSQParam *param = [[LYQSSQParam alloc] init];
    
    NSString *NumStr = [numArray componentsJoinedByString:@" "];

    NumStr = [NumStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    param.stakeNumber = [NSString stringWithFormat:@"%@:%@",NumStr,sexModel.blueText];
    [LYQRequestTool POSTURL:nil params:param.mj_keyValues success:^(id responseObject) {
        
        NSMutableArray *awardModels = [LYQAwardModel mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
        [awardModels enumerateObjectsUsingBlock:^(LYQAwardModel *model , NSUInteger idx, BOOL * _Nonnull stop) {
            if ([model.levelName isEqualToString:@"一等奖"]) {
                self.yiDengCount.text = model.awardNum;
                self.yiDengNumber.text = model.awardNo;
                self.yiDengTime.text = model.lastTime;
            }
            if ([model.levelName isEqualToString:@"二等奖"]) {
                self.erDengCount.text = model.awardNum;
                self.erDengNumber.text = model.awardNo;
                self.erDengTime.text = model.lastTime;

            }
        }];
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
  
    
    NSLog(@"%@",param.stakeNumber);
    
    NSInteger count =  sexModel.redOneNumberModelArrays.count;
    CGFloat redBool_W = 30;
    CGFloat redBool_H = 30;
    CGFloat redBool_X = 0;
    CGFloat redBool_Y =( 44 - redBool_H ) * 0.5;
    
    CGFloat redBool_marge = 5;
    
    for (NSInteger i = 0 ; i < count + 1 ; i ++) {
    
        redBool_X = 10 + i * redBool_marge + i * redBool_W;
        UILabel *redLabel = [[UILabel alloc] init];
        redLabel.frame = CGRectMake(redBool_X, redBool_Y, redBool_W, redBool_H);
        redLabel.layer.cornerRadius = redBool_H * 0.5;
        redLabel.textColor = [UIColor whiteColor];
        redLabel.font = [UIFont systemFontOfSize:14];
        redLabel.textAlignment = NSTextAlignmentCenter;
        redLabel.layer.masksToBounds = YES;
        
        if (i < count) {
            LYQRedOneNumberModel *oneRed = sexModel.redOneNumberModelArrays[i];
            redLabel.text = [NSString stringWithFormat:@"%02ld",oneRed.redNumber];
            if (oneRed.isRight) {
                redLabel.backgroundColor = [UIColor greenColor];
                redLabel.textColor = [UIColor redColor];
            }else if(oneRed.isKillNumber){
                
                redLabel.backgroundColor = [UIColor whiteColor];
                
            }else{
                
                redLabel.backgroundColor = [UIColor redColor];
            }
            
        }else{
            
            redLabel.text = sexModel.blueText;
            redLabel.backgroundColor = [UIColor blueColor];

            
        }
        
            self.srcV.contentSize = CGSizeMake(redLabel.frame.origin.x + 50, 0);
        
        
        
            [self.srcV addSubview:redLabel];
 
        
      
    }

    
    
}

@end
