//
//  LYQNavController.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQNavController : UINavigationController

@end
