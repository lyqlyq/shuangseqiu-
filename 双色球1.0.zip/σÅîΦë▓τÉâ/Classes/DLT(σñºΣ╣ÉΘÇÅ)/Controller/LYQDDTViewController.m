//
//  LYQDDTViewController.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQDDTViewController.h"
#import "LYQRandomNumberTool.h"

@interface LYQDDTViewController ()
@property (weak, nonatomic) IBOutlet UITextField *a;
@property (weak, nonatomic) IBOutlet UITextField *b;
@property (weak, nonatomic) IBOutlet UITextField *c;
@property (weak, nonatomic) IBOutlet UITextField *d;
@property (weak, nonatomic) IBOutlet UITextField *e;
@property (weak, nonatomic) IBOutlet UITextField *f;


@property (weak, nonatomic) IBOutlet UITextField *l;
@property (weak, nonatomic) IBOutlet UITextField *m;
@property (weak, nonatomic) IBOutlet UITextField *n;
@property (weak, nonatomic) IBOutlet UITextField *o;
@property (weak, nonatomic) IBOutlet UITextField *p;
@property (weak, nonatomic) IBOutlet UITextField *q;


@property (weak, nonatomic) IBOutlet UITextField *w;
@property (weak, nonatomic) IBOutlet UITextField *r;
@property (weak, nonatomic) IBOutlet UITextField *s;
@property (weak, nonatomic) IBOutlet UITextField *t;
@property (weak, nonatomic) IBOutlet UITextField *u ;
@property (weak, nonatomic) IBOutlet UITextField *v;

@property (weak, nonatomic) IBOutlet UITextField *x;
@property (weak, nonatomic) IBOutlet UITextField *y;
@property (weak, nonatomic) IBOutlet UITextField *z;
@property (weak, nonatomic) IBOutlet UITextField *aa;
@property (weak, nonatomic) IBOutlet UITextField *bb;

@property (nonatomic ,strong) NSMutableArray *textArray;
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UITextField *countT;

@property (nonatomic ,strong) NSMutableArray *btns;

@property (weak, nonatomic) IBOutlet UITextField *cc;


@end



@implementation LYQDDTViewController

-(NSMutableArray *)btns{
    if (_btns == nil) {
        _btns = [NSMutableArray array];
    }
    return _btns;
}

-(NSMutableArray *)textArray{
    if (_textArray == nil) {
        _textArray = [NSMutableArray array];
    }
    return _textArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //每个Item宽高
    CGFloat W = 40;
    CGFloat H = 40;
    //每行列数
    NSInteger rank = 7;
    //每列间距
    CGFloat rankMargin = (self.contentView.frame.size.width - rank * W ) / (rank - 1);
    //每行间距
    CGFloat rowMargin = 20;
    //Item索引 ->根据需求改变索引
    NSUInteger index = 35;
    
    for (int i = 0 ; i< index; i++) {
        //Item X轴
        CGFloat X = (i % rank) * (W + rankMargin) ;
        //Item Y轴
        NSUInteger Y = (i / rank) * (H +rowMargin);
        //Item top
        CGFloat top = 5;
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.backgroundColor = [UIColor redColor];
        btn.layer.cornerRadius = W * 0.5;
        btn.layer.masksToBounds = YES;
        [btn setTitle:[NSString stringWithFormat:@"%02ld",i + 1] forState:UIControlStateNormal];
        [self.btns addObject:btn];
        btn.frame = CGRectMake(X, Y+top, W, H);
        [self.contentView addSubview:btn];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
 
}

- (IBAction)start:(id)sender {
    
    [self.textArray removeAllObjects];
    
    [self.btns enumerateObjectsUsingBlock:^(UIButton *btn, NSUInteger idx, BOOL * _Nonnull stop) {
        btn.hidden = NO;
    }];
    
    
    [self.textArray addObject:self.a.text];
    [self.textArray addObject:self.b.text];
    [self.textArray addObject:self.c.text];
    [self.textArray addObject:self.d.text];
    [self.textArray addObject:self.e.text];
    [self.textArray addObject:self.f.text];
    
    [self.textArray addObject:self.l.text];
    [self.textArray addObject:self.m.text];
    [self.textArray addObject:self.n.text];
    [self.textArray addObject:self.o.text];
    [self.textArray addObject:self.p.text];
    [self.textArray addObject:self.q.text];
    
    [self.textArray addObject:self.r.text];
    [self.textArray addObject:self.s.text];
    [self.textArray addObject:self.t.text];
    [self.textArray addObject:self.u.text];
    [self.textArray addObject:self.v.text];
    [self.textArray addObject:self.w.text];
    
    [self.textArray addObject:self.x.text];
    [self.textArray addObject:self.y.text];
    [self.textArray addObject:self.z.text];
    [self.textArray addObject:self.aa.text];
    [self.textArray addObject:self.bb.text];
    [self.textArray addObject:self.cc.text];
    
    NSInteger count = [self.countT.text integerValue];
    
    
    for (NSInteger i = 0 ; i < count; i ++) {
       NSInteger index =  [LYQRandomNumberTool getRedNumberWithOneTO22];
        
        NSString *text =  self.textArray[index];
        
        [self.btns enumerateObjectsUsingBlock:^(UIButton *btn, NSUInteger idx, BOOL * _Nonnull stop) {
            if (btn.titleLabel.text.integerValue == text.integerValue) {
                btn.hidden = YES;
            }
        }];
        
        
    }
    
   

    
}


@end
