//
//  LYQRedCell.m
//  双色球
//
//  Created by pro on 2018/3/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRedCell.h"

@implementation LYQRedCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
