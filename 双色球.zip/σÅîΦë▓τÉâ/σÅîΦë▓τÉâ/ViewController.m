//
//  ViewController.m
//  双色球
//
//  Created by pro on 2018/2/6.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "ViewController.h"
#import "LYQCountView.h"
#import "LyqRedModel.h"
#import "TuiJieViewController.h"
@interface ViewController ()
@property (nonatomic ,strong) NSMutableArray *redBollArrays;
@property (nonatomic ,strong) NSMutableArray *blueBollArrays;
@property (weak, nonatomic) IBOutlet UITextField *countTextF;

/**label*/
@property (nonatomic ,strong) NSMutableArray *redBollLabelArrays;

@property (weak, nonatomic) IBOutlet UILabel *hintLabel;
@property (weak, nonatomic) IBOutlet UIButton *tujieButton;

@property (weak, nonatomic) IBOutlet UIView *bottomView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.redBollArrays = [NSMutableArray array];
    for (NSInteger i = 1 ; i <= 33; i ++) {
        [self.redBollArrays addObject:@(i)];
    }
    self.blueBollArrays = [NSMutableArray array];
    for (NSInteger i = 1; i <= 16 ; i ++) {
        [self.blueBollArrays addObject:@(1)];
    }
    
    self.redBollLabelArrays = [NSMutableArray array];

    [self setUpBottomView];
    [self.countTextF addTarget:self action:@selector(countTextChange) forControlEvents:UIControlEventEditingChanged];
    
    
    
}

-(void)countTextChange{
    
    self.hintLabel.text = [NSString stringWithFormat:@"摇奖-%@-次--所有红球出现的次数",self.countTextF.text];
    
}

-(void)setUpBottomView{
    
    
#define kAppViewH 50 //每个小视图高80
#define kAppViewW 30 //每个小视图宽80
#define kColCount 7 //每行视图数量一定，都是三个
#define kStart 0   //适配屏幕，起点20
    CGFloat marginX = (self.bottomView.frame.size.width - kColCount * kAppViewW) / (kColCount + 1);//每一列的x值一定
    CGFloat marginY = 10;//每一行的Y值一定由行号决定
    for (int i= 1 ; i<= 33; i++) {
        //行号
        int row = (i - 1)/kColCount;
        
        //列号
        int col = (i-1)%kColCount;
        
        //x - 由列号决定
        CGFloat x = marginX + col * (kAppViewW + marginX);
        
        //y - 由行号决定
        CGFloat y = kStart + marginY + row * (kAppViewH + marginY);
        
        //CGFloat
        LYQCountView *appView = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([LYQCountView class]) owner:nil options:nil] firstObject];
        appView.backgroundColor = [UIColor clearColor];
        appView.frame = CGRectMake(x, y, kAppViewW, kAppViewH);
        
        NSString *redText = [NSString stringWithFormat:@"%02d",i];
        
        appView.bollLabel.text = redText;
        appView.countLabel.text = @"0";
 
        [self.redBollLabelArrays addObject:appView];
        [self.bottomView addSubview:appView];
    }

    
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


- (IBAction)startClick:(UIButton *)sender {
    
    sender.userInteractionEnabled = NO;
    
    NSInteger count = [self.countTextF.text integerValue];
    
    for (NSInteger i = 0 ; i < count; i ++) {
        LyqRedModel *model = [[LyqRedModel alloc] init];
        
        [model.rednumArrays enumerateObjectsUsingBlock:^(NSNumber *n , NSUInteger idx, BOOL * _Nonnull stop) {
            
            NSInteger desRedBoll = [n integerValue];
            
            
         __block CGFloat maxNum = MAXFRAG;
            
            [self.redBollLabelArrays enumerateObjectsUsingBlock:^(LYQCountView *contView, NSUInteger idx, BOOL * _Nonnull stop) {
                
                NSInteger redBoll =   [contView.bollLabel.text integerValue];
                
                if (redBoll == desRedBoll) {
                    NSInteger count =  [contView.countLabel.text integerValue];
                    count ++;
                    contView.countLabel.text = [NSString stringWithFormat:@"%ld",count];
                    
                    
                }
                
            }];
            
        }];
        
    }
    sender.userInteractionEnabled = YES;

}

- (IBAction)clearClick:(UIButton *)sender {
 
        
        [self.redBollLabelArrays enumerateObjectsUsingBlock:^(LYQCountView *contView, NSUInteger idx, BOOL * _Nonnull stop) {
            contView.countLabel.text = @"0";
        }] ;
    
}

- (IBAction)tujieClick:(id)sender {
    
    TuiJieViewController *v = [[TuiJieViewController alloc] init];
    
    [self presentViewController:v animated:YES completion:nil];
}




@end
