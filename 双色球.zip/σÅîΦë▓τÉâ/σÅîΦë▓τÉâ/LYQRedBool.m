//
//  LYQRedBool.m
//  双色球
//
//  Created by pro on 2018/3/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRedBool.h"

@implementation LYQRedBool

@end
