//
//  TuiJieViewController.m
//  双色球
//
//  Created by pro on 2018/2/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "TuiJieViewController.h"
#import "TuJieModel.h"
#import "LYQRedBool.h"
#import "LYQRedCell.h"

@interface TuiJieViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tbaleView;
@property (weak, nonatomic) IBOutlet UITextField *startTextF;
@property (weak, nonatomic) IBOutlet UITextField *endTextF;

@property (nonatomic ,strong) NSMutableArray *countArray;

@property (nonatomic ,strong) NSMutableArray *addNumArray;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;
@property (weak, nonatomic) IBOutlet UILabel *countErrorLabel;


@property (weak, nonatomic) IBOutlet UITextField *textF1;
@property (weak, nonatomic) IBOutlet UITextField *textF2;
@property (weak, nonatomic) IBOutlet UITextField *textF3;
@property (weak, nonatomic) IBOutlet UITextField *textF4;
@property (weak, nonatomic) IBOutlet UITextField *textF5;

@property (weak, nonatomic) IBOutlet UILabel *countLabel;

@property (nonatomic ,assign) NSInteger countLabelText;



@property (nonatomic ,strong) NSMutableArray *redLabels;

@property (weak, nonatomic) IBOutlet UITextField *red1;
@property (weak, nonatomic) IBOutlet UITextField *red2;
@property (weak, nonatomic) IBOutlet UITextField *red3;
@property (weak, nonatomic) IBOutlet UITextField *red4;
@property (weak, nonatomic) IBOutlet UITextField *red5;
@property (weak, nonatomic) IBOutlet UITextField *red6;

/**当前开奖号码*/
@property (nonatomic ,strong) NSMutableArray *redBools;

/**是否需要对比*/
@property (nonatomic ,assign) BOOL isShowGreen;

@property (weak, nonatomic) IBOutlet UILabel *timeLbale;


@end

@implementation TuiJieViewController


-(NSMutableArray *)redBools{
    if (_redBools == nil) {
        _redBools = [NSMutableArray array];
    }
    return _redBools;
}

-(NSMutableArray *)redLabels{
    
    if (_redLabels == nil) {
        
        _redLabels = [NSMutableArray array];
    }
    return _redLabels ;
    
}

-(NSMutableArray *)addNumArray{
    if (_addNumArray == nil) {
        _addNumArray = [NSMutableArray array];
    }
    return _addNumArray ;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // 41538
  //  self.addNumArray = @[@(9),@(3),@(2),@(4),@(8),@(5),@(1)];
   // self.addNumArray = @[@(4),@(1),@(5),@(3),@(8),@(10),@(11)];
    
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"yyyy-MM-dd"];
    NSString *dateStr;
    dateStr=[format1 stringFromDate:date];
    self.timeLbale.text =[NSString stringWithFormat:@"当前日期:%@",dateStr] ;

    self.countLabelText = 0;

    self.countArray = [NSMutableArray array];
    
    [self.endTextF addTarget:self action:@selector(endTextfChange) forControlEvents:UIControlEventEditingChanged];
    
    [self.startTextF addTarget:self action:@selector(startTextFChange) forControlEvents:UIControlEventEditingChanged];
    
    
    self.tbaleView.tableFooterView = [[UIView alloc]init];
    
    
}


-(void)endTextfChange{
    if (self.endTextF.text.length > 0) {
        self.countErrorLabel.hidden = YES;

    }else{
        self.countErrorLabel.hidden = NO;
    }
}

-(void)startTextFChange{

    self.countLabelText = 0;
    if (self.startTextF.text.length > 0) {
        if ([self.startTextF.text integerValue] > 29) {
            self.errorLabel.hidden = NO;
        }else{
            self.errorLabel.hidden = YES;

        }
    
    }else{
        self.errorLabel.hidden = NO;
    }
}

#pragma mark - set方法
- (void)removeRepeatWithNSSetFunc:(NSArray *)array {
    NSMutableSet *set = [NSMutableSet set];
    for (NSNumber *str in array) {
        [set addObject:str];
    }
    NSLog(@"setFunc ===== %@", set);
}


- (IBAction)startClick:(id)sender {

    [self.view endEditing:YES];
    if (!self.errorLabel.hidden) return;
    
    NSMutableArray *textFArray = [NSMutableArray array];
    NSMutableArray *redsText = [NSMutableArray array];
    [textFArray addObject:self.textF1];
    [textFArray addObject:self.textF2];
    [textFArray addObject:self.textF3];
    [textFArray addObject:self.textF4];
    [textFArray addObject:self.textF5];
    
    [redsText addObject:self.red1];
    [redsText addObject:self.red2];
    [redsText addObject:self.red3];
    [redsText addObject:self.red4];
    [redsText addObject:self.red5];
    [redsText addObject:self.red6];

    
    [self.addNumArray removeAllObjects];
    
    /**间隔*/
    for (NSInteger i = 0 ; i < textFArray.count; i ++) {
        UITextField *textF = textFArray[i];
        NSNumber *num = [NSNumber numberWithInteger:[textF.text integerValue]];
        if (num.integerValue != 0) {
            [self.addNumArray addObject:num];
        }
        
    }
    
    [self.redBools removeAllObjects];
    /**当前开奖号码*/
    for (NSInteger i = 0 ; i < redsText.count; i ++) {
        UITextField *textF = redsText[i];
        NSNumber *num = [NSNumber numberWithInteger:[textF.text integerValue]];
        if (num.integerValue != 0) {
            [self.redBools addObject:num];
        }
        
    }
    
    if (self.redBools.count == 6) {
        self.isShowGreen = YES;
    }else{
        self.isShowGreen = NO;
    }
    
    
    /**间隔不足3位*/
    if (self.addNumArray.count <3) {
        return;
    }
    
    self.countLabelText ++;
    self.countLabel.text = [NSString stringWithFormat:@"%ld",self.countLabelText];
    
    [self.countArray removeAllObjects];
    NSInteger countNum = [self.endTextF.text integerValue];

    for (NSInteger i = 0 ; i < countNum ; i ++) {

        NSInteger startNum = [self.startTextF.text integerValue];
        NSMutableArray *redArray = [NSMutableArray arrayWithCapacity:6];
        TuJieModel *redModel = [[TuJieModel  alloc] init];
        LYQRedBool *red = [[LYQRedBool alloc] init];
        red.redNum = startNum;
        if ([self.redBools containsObject:[NSNumber numberWithInteger:startNum]] && self.isShowGreen) {
            red.isShow = YES;
        }
        [redArray addObject:red];
        
        for (NSInteger j = 1 ; j < 6; j ++) {
            LYQRedBool *nextRed = [[LYQRedBool alloc] init];
            NSInteger index = [self.addNumArray[[self getRandomNumber:0 to:self.addNumArray.count]]  integerValue];
             startNum = index + startNum;
            if (startNum > 33) {
                startNum = [self quChong:redArray];
                redModel.isMAX_33 = YES;
            }
            
            if ([self.redBools containsObject:[NSNumber numberWithInteger:startNum]] && self.isShowGreen) {
                nextRed.isShow = YES;
            }
            
             nextRed.redNum = startNum;
             [redArray addObject:nextRed];

        }
        
         [redArray sortUsingComparator:^NSComparisonResult(LYQRedBool  *obj1, LYQRedBool *obj2) {
             return [[NSNumber numberWithInteger:obj1.redNum] compare:[NSNumber numberWithInteger:obj2.redNum]];
         }];
        

        redModel.redBoolArray = redArray;
        [self.countArray addObject:redModel];
        [self.tbaleView reloadData];
      
    }
    
    
    
}

/**去掉重复的号码*/
-(NSInteger)quChong:(NSArray *)numArrays{
    
  int index = [self getRandomNumber:[self.startTextF.text integerValue] to:33];
 NSNumber *indexNum = [NSNumber numberWithInt:index];
  BOOL isBool   =  [numArrays containsObject:indexNum];
    if (isBool) {
        return [self quChong:numArrays];
    }else{
        return index;
    }
    
}

-(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from )));
    
}

- (IBAction)blackClick:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
    
}


#define cell_H  46
#define label_WH 36

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.countArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    

    LYQRedCell  * cell = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([LYQRedCell class]) owner:nil options:nil] firstObject];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    TuJieModel *model   =  self.countArray[indexPath.row];
    cell.countLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    CGFloat label_Y = (cell_H - label_WH) *0.5;
    CGFloat label_W = label_WH;
    CGFloat label_H = label_WH;
    CGFloat count = 7;
    CGFloat marginX = (cell.redView.bounds.size.width - count * label_W) / (count + 1);
     CGFloat label_X = marginX;
    
    for (NSInteger i = 0 ; i < model.redBoolArray.count + 1;i++ ) {
      
        UILabel *label = [[UILabel alloc] init];
        label_X = i * marginX + i * label_W + marginX;
        label.frame = CGRectMake(label_X, label_Y, label_W, label_H);
        label.layer.cornerRadius = label_W * 0.5;
        label.layer.masksToBounds = YES;
        label.font = [UIFont systemFontOfSize:15];
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        if (i < model.redBoolArray.count) {
            LYQRedBool *redBool = model.redBoolArray[i];
            label.text = [NSString stringWithFormat:@"%02ld",redBool.redNum];
            if (redBool.isShow) {
                label.backgroundColor = [UIColor greenColor];
            }else{
                label.backgroundColor = [UIColor redColor];
            }
        }else{
            label.text = model.blueText;
            if (model.isMAX_33) {
                label.backgroundColor = [UIColor orangeColor];
            }else{
                label.backgroundColor = [UIColor blueColor];
            }
        }
        
        [cell.redView addSubview:label];
        
    }

    
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return cell_H;
}



@end
