//
//  LYQTabBarController.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTabBarController.h"
#import "LYQNavController.h"
#import "LYQSSQViewController.h"
#import "LYQDDTViewController.h"

@interface LYQTabBarController ()

@end

@implementation LYQTabBarController




- (void)viewDidLoad {
    [super viewDidLoad];
    LYQSSQViewController *ssqVC = [[LYQSSQViewController alloc] init];
    LYQNavController *ssqNav = [[LYQNavController alloc] initWithRootViewController:ssqVC];
    
    ssqVC.title = @"双色球";

    LYQDDTViewController *dltVC = [[LYQDDTViewController alloc] init];
    LYQNavController *dltNav = [[LYQNavController alloc] initWithRootViewController:dltVC];

    dltVC.title = @"大乐透";

    [self addChildViewController:ssqNav];
    [self addChildViewController:dltNav];
    
}

+ (void)initialize{
    UITabBarItem *item = [UITabBarItem appearanceWhenContainedIn:self, nil];
    
    // 设置所有item的选中时颜色
    // 设置选中文字颜色
    // 创建字典去描述文本
    NSMutableDictionary *attr = [NSMutableDictionary dictionary];
    // 文本颜色 -> 描述富文本属性的key -> NSAttributedString.h
    attr[NSForegroundColorAttributeName] = [UIColor redColor];
    attr[NSFontAttributeName] = [UIFont systemFontOfSize:16];
    [item setTitleTextAttributes:attr forState:UIControlStateSelected];

    // 通过normal状态设置字体大小
    // 字体大小 跟 normal
    NSMutableDictionary *attrnor = [NSMutableDictionary dictionary];
    
    // 设置字体
    attrnor[NSFontAttributeName] = [UIFont systemFontOfSize:16];
    attrnor[NSForegroundColorAttributeName] = [UIColor grayColor];

    [item setTitleTextAttributes:attrnor forState:UIControlStateNormal];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
