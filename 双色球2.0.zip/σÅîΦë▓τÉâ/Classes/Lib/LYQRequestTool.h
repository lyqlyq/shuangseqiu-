//
//  LYQRequestTool.h
//  quanzhouda
//
//  Created by pro on 2017/11/30.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking.h>

@interface LYQRequestTool : NSObject

/**
 url     -  请求地址
 params  -  参数
 success - 成功的回调
 failure - 失败的回调
 message - 显示信息
 isShow  - 是否显示信息
 */
+(void)POSTURL:(NSString *)url params:(NSDictionary *)params success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure showMessage:(NSString *)message isShowMessage:(BOOL)isShow;


@end
