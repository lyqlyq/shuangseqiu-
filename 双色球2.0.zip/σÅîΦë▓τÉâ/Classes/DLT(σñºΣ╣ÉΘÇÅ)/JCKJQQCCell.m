//
//  JCKJQQCCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJQQCCell.h"

#import "JCKJQQCModel.h"
#import "JCKJQQCRedModel.h"

@interface JCKJQQCCell()
@property (weak, nonatomic) IBOutlet UIView *contentV;

@end

@implementation JCKJQQCCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype)qqcCellWithTableView:(UITableView *)tableView{
    
    JCKJQQCCell *cell = [[[NSBundle mainBundle] loadNibNamed:@"JCKJQQCCell" owner:nil options:nil] firstObject];
    
    return cell;
}

-(void)setModel:(JCKJQQCModel *)model{
    _model = model;
    
    
    CGFloat redLabel_W = 40;
    CGFloat redLabel_H = 40;
    
    CGFloat redLabel_X = 5;
    CGFloat redLabel_Y = (self.contentV.frame.size.height - redLabel_H) * 0.5;
    
    CGFloat marge_X = 5;


    
    
    for (NSInteger i = 0 ; i < model.numTextArrays.count ; i ++) {
        
        
        JCKJQQCRedModel *redModel = model.numTextArrays[i];
        
        UILabel *redLabel = [[UILabel alloc] init];
        
        redLabel.layer.masksToBounds = YES;
        redLabel.layer.cornerRadius = redLabel_W * 0.5;
        
        redLabel.backgroundColor = [UIColor redColor];
        
        redLabel.textColor = [UIColor whiteColor];
        
        redLabel.text = redModel.redText;
        
        redLabel.font = [UIFont systemFontOfSize:13];
        
        redLabel_X = i * (redLabel_W + marge_X);
        
        redLabel.textAlignment = NSTextAlignmentCenter;
        
        redLabel.frame = CGRectMake(redLabel_X, redLabel_Y, redLabel_W, redLabel_H);
        
        if (redModel.isYes) {
            redLabel.backgroundColor = [UIColor greenColor];
            redLabel.textColor = [UIColor redColor];
        }
        
        
        [self.contentV addSubview:redLabel];
    }
    
    
    
}

@end
