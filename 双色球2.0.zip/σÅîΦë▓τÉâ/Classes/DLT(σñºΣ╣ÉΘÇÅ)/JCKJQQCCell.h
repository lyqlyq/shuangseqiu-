//
//  JCKJQQCCell.h
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class JCKJQQCModel;

@interface JCKJQQCCell : UITableViewCell


@property (nonatomic ,strong) JCKJQQCModel *model;

@property (weak, nonatomic) IBOutlet UILabel *countLabel;


+(instancetype)qqcCellWithTableView:(UITableView *)tableView;

@end
