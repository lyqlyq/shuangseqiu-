//
//  JCKJQQCModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJQQCRedModel;
@interface JCKJQQCModel : NSObject

@property (nonatomic ,strong) NSMutableArray <JCKJQQCRedModel *> * numTextArrays;

+(JCKJQQCModel *)getQQC_7_numberWithDDQQ:(NSMutableArray <JCKJQQCRedModel *>*)qqcNumBerArray isYesModels:(JCKJQQCModel *)yesModel;


@end
