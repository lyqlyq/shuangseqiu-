//
//  JCKJQQCRedModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJQQCRedModel.h"

@implementation JCKJQQCRedModel

@end
