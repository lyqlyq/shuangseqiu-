//
//  LYQQXCViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQQXCViewController.h"
#import "JCKJQQCRedModel.h"
#import "JCKJQQCModel.h"
#import "JCKJQQCCell.h"

@interface LYQQXCViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITextField *dan1;
@property (weak, nonatomic) IBOutlet UITextField *dan2;
@property (weak, nonatomic) IBOutlet UITextField *dan3;
@property (weak, nonatomic) IBOutlet UITextField *dan4;
@property (weak, nonatomic) IBOutlet UITextField *dan5;

@property (weak, nonatomic) IBOutlet UITextField *k1;

@property (weak, nonatomic) IBOutlet UITextField *k2;
@property (weak, nonatomic) IBOutlet UITextField *k3;
@property (weak, nonatomic) IBOutlet UITextField *k4;
@property (weak, nonatomic) IBOutlet UITextField *k5;
@property (weak, nonatomic) IBOutlet UITextField *k6;
@property (weak, nonatomic) IBOutlet UITextField *k7;

@property (nonatomic ,strong) JCKJQQCModel *kModel;

@property (nonatomic ,strong) NSMutableArray *dataModels;


@property (weak, nonatomic) IBOutlet UITableView *tableVIew;
@end




@implementation LYQQXCViewController


-(JCKJQQCModel *)kModel{
    if (_kModel == nil) {
        _kModel = [[JCKJQQCModel alloc] init];
    }
    return _kModel;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"七星彩选号";
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor redColor]}];
    
    self.tableVIew.rowHeight = 60;
   
    
}
- (IBAction)startCLick:(UIButton *)sender {
    
    
    NSMutableArray *models = [NSMutableArray array];
    
    for (NSInteger i = 0 ; i < 500 ; i ++) {
       JCKJQQCModel * model  =  [JCKJQQCModel getQQC_7_numberWithDDQQ:[self getDanNumber] isYesModels:[self  getKModel]];
        
        [models addObject:model];
        
    }
    
    self.dataModels = models;
    
    [self.tableVIew reloadData];
    
}


-(NSMutableArray <JCKJQQCRedModel *>*)getDanNumber{
    
    NSMutableArray <JCKJQQCRedModel *>*redModels = [NSMutableArray array];
    
    NSMutableArray *rTextF = [NSMutableArray array];

    [rTextF addObject:self.dan1];
    [rTextF addObject:self.dan2];
    [rTextF addObject:self.dan3];
    [rTextF addObject:self.dan4];
    [rTextF addObject:self.dan5];
    
    for (NSInteger i = 0 ; i < 5 ; i ++) {
        
        JCKJQQCRedModel *redModel = [[JCKJQQCRedModel alloc] init];
        
        UITextField *textF  =  rTextF[i];
        
        
        if (textF.text.length > 0) {
            redModel.redText = textF.text;
        }
        
        [redModels addObject:redModel];
        
    }
    
    

    return redModels;
    
    
}

-(JCKJQQCModel *)getKModel{
    
    
    [self.kModel.numTextArrays removeAllObjects];
    
    NSMutableArray *kTextF = [NSMutableArray array];
    [kTextF addObject:self.k1];
    [kTextF addObject:self.k2];
    [kTextF addObject:self.k3];
    [kTextF addObject:self.k4];
    [kTextF addObject:self.k5];
    [kTextF addObject:self.k6];
    [kTextF addObject:self.k7];
    
    for (NSInteger i = 0 ; i < 7 ; i ++) {
        
        JCKJQQCRedModel *redModel = [[JCKJQQCRedModel alloc] init];
        
       UITextField *textF  =  kTextF[i];
        
        redModel.redText = textF.text;
        
        [self.kModel.numTextArrays addObject:redModel];
        
        
    }
    
    
    

    return self.kModel;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.dataModels.count;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJQQCCell *cell = [JCKJQQCCell qqcCellWithTableView:tableView];
    
    cell.model = self.dataModels[indexPath.row];
    
    cell.countLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    
    return cell;
}




@end
