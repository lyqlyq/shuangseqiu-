//
//  JCKJQQCRedModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJQQCRedModel : NSObject


@property (nonatomic ,copy) NSString *redText;

@property (nonatomic ,assign) BOOL isYes;

@end
