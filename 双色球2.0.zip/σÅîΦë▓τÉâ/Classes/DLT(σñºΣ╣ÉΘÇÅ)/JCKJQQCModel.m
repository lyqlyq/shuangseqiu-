//
//  JCKJQQCModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/5/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJQQCModel.h"
#import "JCKJQQCRedModel.h"

@interface JCKJQQCModel()

@end

@implementation JCKJQQCModel



-(NSMutableArray<JCKJQQCRedModel *> *)numTextArrays{
    
    if (_numTextArrays == nil) {
        _numTextArrays = [NSMutableArray array];
    }
    return _numTextArrays;
    
}


+(JCKJQQCModel *)getQQC_7_numberWithDDQQ:(NSMutableArray <JCKJQQCRedModel *>*)qqcNumBerArray isYesModels:(JCKJQQCModel *)yesModel{
    

    
    if (qqcNumBerArray.count >= 4 ) {
     
        return [self getModelWithArrays:qqcNumBerArray withRedModels:yesModel];
        
    }else{

        
        // 4 个 或者 5 个
        NSInteger redNum = [self getRandomNumber:4 to:5];
        
        
        // 删除有的
       
        
        // 随机不够的
        
        
        
        
        
        
        
    }
    
    // 4
    // 5
    
    
    return nil;
    
}


//+(NSMutableArray *)get_NO_ArrWithGS:(NSInteger)redNum HasArray:(NSMutableArray *)hasArrays noHasArrays:(NSMutableArray *)noHasArrays{
//
//    NSInteger sxdNum = redNum - hasArrays.count;
//    NSMutableArray *numArrays = [NSMutableArray array];
//
//    for (NSInteger i = 0 ; i < sxdNum; i ++) {
//
//        NSInteger index = [self getRandomNumber:0 to:noHasArrays.count - 1];
//
//        NSString *desText = noHasArrays[index];
//
//        [numArrays addObject:desText];
//
//    }
//
//    return numArrays;
//
//
//
//}

+(JCKJQQCModel *)getModelWithArrays:(NSMutableArray <JCKJQQCRedModel *>*)numArrays withRedModels:(JCKJQQCModel *)yesModel{
    
    
    JCKJQQCModel *model = [[JCKJQQCModel alloc] init];
    
    
    for (NSInteger i = 0 ; i < 7 ; i ++) {
        
        JCKJQQCRedModel *redModel =  yesModel.numTextArrays[i];
        
        JCKJQQCRedModel *getredModel = [self getSuiJITextWithArrays:numArrays];
        
        if ([redModel.redText isEqualToString:getredModel.redText]) {
            getredModel.isYes = YES;
        }
        [model.numTextArrays addObject:getredModel];
        
    }
    
    return model;
}


+(JCKJQQCRedModel *)getSuiJITextWithArrays:(NSMutableArray <JCKJQQCRedModel *>*)numberArrays{
    
    NSInteger index = [self getRandomNumber:0 to:numberArrays.count - 1];
    
    JCKJQQCRedModel *red = numberArrays[index];
    
    JCKJQQCRedModel *model = [[JCKJQQCRedModel alloc] init];
    
    model.redText = red.redText;
    
    
    return model;
    
}

+(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from + 1)));
}


@end
