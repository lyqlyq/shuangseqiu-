//
//  LYQKillNumberModel.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQKillNumberModel : NSObject


@property (nonatomic ,assign) NSInteger killNumOne;
@property (nonatomic ,assign) NSInteger killNumTwo;
@property (nonatomic ,assign) NSInteger killNumThere;
@property (nonatomic ,assign) NSInteger killNumFour;
@property (nonatomic ,assign) NSInteger killNumFive;
@property (nonatomic ,assign) NSInteger killNumSex;


@property (nonatomic ,strong) NSMutableArray *killNumberArrays;

@property (nonatomic ,copy) NSString *killNumOneText;
@property (nonatomic ,copy) NSString *killNumTwoText;
@property (nonatomic ,copy) NSString *killNumThereText;
@property (nonatomic ,copy) NSString *killNumFourText;
@property (nonatomic ,copy) NSString *killNumFiveText;
@property (nonatomic ,copy) NSString *killNumSexText;



@end
