//
//  LYQAwardModel.m
//  双色球
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQAwardModel.h"

@implementation LYQAwardModel

@end
