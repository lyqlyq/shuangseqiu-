//
//  LYQRedSexNumberModel.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LYQPotentialModel;
@class LYQConditionModel;
@class LYQRedOneNumberModel;
@class LYQKillNumberModel;

@interface LYQRedSexNumberModel : NSObject

/**当前开奖号码*/
@property (nonatomic ,strong) NSMutableArray <LYQRedOneNumberModel *>*redOneNumberModelArrays;

/**蓝球*/
@property (nonatomic ,copy) NSString *blueText;

@property (nonatomic ,assign) BOOL isMaxOver_33;

/**6 红*/
@property (nonatomic ,assign) BOOL is_sex_red;

@property (nonatomic ,strong) NSMutableArray *lanArrays;


/**根据位差，龙头 ，凤尾 ，生产号码*/
+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel;

/**根据位差，龙头 ，凤尾 ，生产号码  标记开奖号码*/
+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel WithRightSexModel:(LYQRedSexNumberModel *)model lanArrays:(NSMutableArray *)lanArrays;

/**杀号*/
+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel killNumberModel:(LYQKillNumberModel *)model;

@end
