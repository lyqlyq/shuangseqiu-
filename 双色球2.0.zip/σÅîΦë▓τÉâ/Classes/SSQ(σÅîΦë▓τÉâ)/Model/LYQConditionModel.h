//
//  LYQConditionModel.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


/**条件*/
@interface LYQConditionModel : NSObject

/**龙头*/
@property (nonatomic ,assign) NSInteger faucetNumber;
/**凤尾*/
@property (nonatomic ,assign) NSInteger pterisNumber;
/**总注数*/
@property (nonatomic ,assign) NSInteger numberTotial;
/**剩下的红球*/
@property (nonatomic ,assign) NSInteger  remainedRedNumber;




@end
