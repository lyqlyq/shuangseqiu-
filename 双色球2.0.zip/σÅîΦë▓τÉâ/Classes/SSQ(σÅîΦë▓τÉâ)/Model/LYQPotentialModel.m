//
//  LYQPotentialModel.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPotentialModel.h"
#import "LYQRandomNumberTool.h"
@implementation LYQPotentialModel



+(instancetype)potentialModelWithRandomNumber{
    
    LYQPotentialModel *model = [[LYQPotentialModel alloc] init];
    model.poentialOne = [LYQRandomNumberTool getRandomPotenial];
    model.poentialTwo = [LYQRandomNumberTool getRandomPotenial];
    model.poentialThere = [LYQRandomNumberTool getRandomPotenial];
    model.poentialFour = [LYQRandomNumberTool getRandomPotenial];
    model.poentialFive = [LYQRandomNumberTool getRandomPotenial];
    return model;
}


-(NSInteger)potentialTotial{
    return 5; 
}

-(NSString *)oneText{
    
    return [NSString stringWithFormat:@"%ld",self.poentialOne];
}
-(NSString *)twoText{
    return [NSString stringWithFormat:@"%ld",self.poentialTwo];

}
-(NSString *)thereText{
    return [NSString stringWithFormat:@"%ld",self.poentialThere];

}
-(NSString *)fourText{
    return [NSString stringWithFormat:@"%ld",self.poentialFour];

    
}
-(NSString *)fiveText{
    return [NSString stringWithFormat:@"%ld",self.poentialFive];

}

-(NSMutableArray *)potentialArray{
    
    NSMutableArray *pArray = [NSMutableArray array];
    if (self.oneText.integerValue > 0) {
        
        [pArray addObject:self.oneText];
    }
    if (self.twoText.integerValue > 0) {
        
        [pArray addObject:self.twoText];
    }
    if (self.thereText.integerValue > 0) {
        
        
        [pArray addObject:self.thereText];
    }
    if (self.fourText.integerValue > 0) {
        
        [pArray addObject:self.fourText];
    }
    if (self.fiveText.integerValue > 0) {
        
        [pArray addObject:self.fiveText];
    }
    
    return pArray;
}

@end
