//
//  LYQRandomNumberTool.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LYQPotentialModel;
@interface LYQRandomNumberTool : NSObject

+(NSInteger)getRandomBlueText;

/**获取随机位差 1 - 10*/
+(NSInteger)getRandomPotenial;
/**1-33 的随机数*/
+(NSInteger)getRedNumberWithOneTO33;
/**1-30 的随机数*/
+(NSInteger)getRedNumberWithOneTO22;

+(NSInteger)getRandomNumber:(int)from to:(int)to;

+(NSString *)getBlueTextWithLanArrays:(NSMutableArray *)lanArrays;


/**根据位差模型--  获取指定的随机位差*/
+(NSInteger)getPotenialNumber:(LYQPotentialModel *)pModel;
+(NSMutableArray *)getRexModesWithArrays:(NSMutableArray *)sexModelsArray count:(NSInteger)count;





@end
