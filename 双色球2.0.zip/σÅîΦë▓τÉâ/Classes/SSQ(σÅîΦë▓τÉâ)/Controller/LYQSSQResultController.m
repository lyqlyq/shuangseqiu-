//
//  LYQSSQResultController.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSSQResultController.h"
#import "LYQRedCell.h"
#import <WXApi.h>

#import "LYQRandomNumberTool.h"
#import "LYQRedOneNumberModel.h"
#import "LYQRedSexNumberModel.h"

@interface LYQSSQResultController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *timeLbale;
@property (weak, nonatomic) IBOutlet UILabel *weiChaLabel;

@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@property (weak, nonatomic) IBOutlet UITextField *countLable;

@property (nonatomic ,strong) NSMutableArray *redSexModels;
@property (nonatomic ,strong) NSMutableArray *redSevenModels;

@end

@implementation LYQSSQResultController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选号结果";
    
    self.timeLbale.text = [self getDateStr];
    
    self.weiChaLabel.text = self.weiChastr;
    
    self.redSexModels = [NSMutableArray array];
    self.redSevenModels = [NSMutableArray array];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"微信分享" style:0 target:self action:@selector(wechatFenXiang)];
    
    self.navigationItem.rightBarButtonItem = item;
    
    
    
}
/**50注*/
-(NSString *)get50TextCount{
   
   self.price = 0;
    [self.redSexModels removeAllObjects];
    [self.redSevenModels removeAllObjects];
    
   NSInteger count = [self.countLable.text integerValue];
    
  __block  NSString *contentText = [NSString new];
 
    
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"%@\n",self.weiChastr]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"总注数:%ld\n",count]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"%@\n",[self getDateStr]]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"蓝球定胆:%@\n",self.lanDan]];
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"红球定胆:%@\n",self.redDan]];
    
      contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"少年微信号:lyq159921995\n\n"]];
    //
    
    NSMutableArray *redModels = [LYQRandomNumberTool getRexModesWithArrays:self.sexModels count:count];
    [redModels enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
    
        if (model.redOneNumberModelArrays.count == 6 ) {
            self.price += 2;
            [self.redSexModels addObject:model];
        }
        if (model.redOneNumberModelArrays.count == 7 ) {
            self.price += 14;
            [self.redSevenModels addObject:model];
        }
        if (model.redOneNumberModelArrays.count == 8 ) {
            self.price += 56;

        }
        if (model.redOneNumberModelArrays.count == 9 ) {
            self.price += 168;

        }
        if (model.redOneNumberModelArrays.count == 10 ) {
            self.price += 420;
        }
        
        
    }];
    
    
    contentText = [contentText stringByAppendingString:[self getFenTextWithArrays:self.redSexModels]];
    
    
    
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"\n---类型:6+1--总计:%ld注-\n\n",self.redSexModels.count]];
    
    
    if (self.redSevenModels.count > 0) {
        contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"\n---类型改变 --7+1类型-\n\n"]];
        
        contentText = [contentText stringByAppendingString:[self getFenTextWithArrays:self.redSevenModels]];
        
        contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"\n---7+1--总计:%ld注-\n",self.redSevenModels.count]];
  
    }
    
    contentText = [contentText stringByAppendingString:[NSString stringWithFormat:@"\n-------总价:%ld--------",self.price]];
    
    
    return contentText;
}


-(NSString *)getFenTextWithArrays:(NSMutableArray *)models{
    
    
    __block NSString *allText = [NSString new];
    
    [models enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        
        
        __block NSString *sevenText = [NSString new];
        
        [model.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneRed, NSUInteger oneidx, BOOL * _Nonnull stop) {
            
            if (oneidx == model.redOneNumberModelArrays.count - 1) {
                sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@"%02ld",oneRed.redNumber]];
            }else{
                sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@"%02ld-",oneRed.redNumber]];
            }
            
        }];
        sevenText = [sevenText stringByAppendingString:[NSString stringWithFormat:@" 蓝-%@ \n",model.blueText]];
        
        allText = [allText stringByAppendingString:sevenText];
        
        if ((idx+1) % 5 == 0) {
            allText = [allText stringByAppendingString:[NSString stringWithFormat:@"\n---类型:%ld+1---第-%ld-注\n\n",model.redOneNumberModelArrays.count,idx + 1]];
        }
        
        
        
    }];
    
    return allText;
}


-(void)wechatFenXiang{
    
    SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
    req.bText = YES;
    req.scene = WXSceneSession;
    req.text = [self get50TextCount];
    
    [WXApi sendReq:req];
    
}

-(NSString *)getDateStr{
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"当前日期:yyyy-MM-dd"];
    return [format1 stringFromDate:date];
}



#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.sexModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQRedCell *cell = [LYQRedCell redCellWithTableView:tableView];
    cell.sexModel = self.sexModels[indexPath.row];
    cell.countLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70.0f;
}




@end
